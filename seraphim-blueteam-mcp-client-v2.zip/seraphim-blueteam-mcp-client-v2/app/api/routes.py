from __future__ import annotations

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse

from app.core.config import settings
from app.core.constants import Menu
from app.models.schemas import APIResponse, PromptRequest, ToolCallRequest
from app.services.audit_service import AuditService
from app.services.event_search.orchestrator import EventSearchOrchestrator
from app.services.fql.orchestrator import FQLOrchestrator
from app.services.guardrail_service import GuardrailService
from app.services.investigation.orchestrator import InvestigationOrchestrator
from app.services.investigation.virustotal_service import VirusTotalService
from app.services.llm_service import LLMService
from app.services.mcp_service import MCPService
from app.services.planner_service import PlannerService
from app.web.templates import HTML_TEMPLATE

router = APIRouter()

mcp_service = MCPService()
llm_service = LLMService()
planner = PlannerService(llm_service)
guardrail = GuardrailService()
audit = AuditService()
vt_service = VirusTotalService()

investigation_orchestrator = InvestigationOrchestrator(mcp_service, planner, vt_service)
event_orchestrator = EventSearchOrchestrator(mcp_service, planner)
fql_orchestrator = FQLOrchestrator(mcp_service, planner)


@router.get("/", response_class=HTMLResponse)
async def index() -> str:
    return HTML_TEMPLATE


@router.get("/api/health")
async def health() -> dict:
    return {
        "app_name": settings.app_name,
        "app_env": settings.app_env,
        "mcp_server_url": settings.mcp_server_url,
        "llm": llm_service.metadata(),
        "virustotal": {"enabled": vt_service.enabled, "ready": vt_service.is_ready()},
        "audit": {"enabled": audit.enabled, "stream_key": audit.stream_key},
    }


@router.get("/api/tools")
async def list_tools() -> dict:
    try:
        return {"tools": await mcp_service.list_tools()}
    except Exception as error:
        raise HTTPException(status_code=500, detail=f"Gagal list MCP tools: {error}")


@router.get("/api/audit/recent")
async def recent_audit(limit: int = 25) -> dict:
    try:
        return {"enabled": audit.enabled, "events": await audit.recent(limit=limit)}
    except Exception as error:
        raise HTTPException(status_code=500, detail=str(error))


@router.post("/api/prompt")
async def run_prompt(req: PromptRequest) -> dict:
    """
    Unified endpoint untuk 3 menu.

    HIGHLIGHT FLOW:
    1. Ambil MCP tools.
    2. LLM Planner membuat structured plan.
    3. Backend Guardrail validasi menu/tool.
    4. Orchestrator sesuai menu menjalankan flow.
    """
    request_id = audit.new_request_id()

    try:
        tools = await mcp_service.list_tools()
    except Exception as error:
        raise HTTPException(status_code=500, detail=f"Gagal mengambil MCP tools: {error}")

    try:
        plan = planner.build_plan(req.menu, req.prompt, tools, req.form_data)
        decision = guardrail.validate_plan(plan, confirmed=req.confirmed)

        await audit.write(
            "plan_created",
            {
                "request_id": request_id,
                "menu": req.menu,
                "prompt": req.prompt,
                "plan": plan.model_dump(),
                "guardrail": decision.model_dump(),
            },
        )

        if not decision.allowed:
            await audit.write("request_blocked", {"request_id": request_id, "reason": decision.reason})
            return APIResponse(
                request_id=request_id,
                menu=req.menu,
                blocked=True,
                message=decision.reason,
                plan=plan,
                guardrail=decision,
            ).model_dump()

        if req.menu == Menu.INVESTIGATION:
            data = await investigation_orchestrator.run(req.prompt, plan)
            summary = data.get("case", {}).get("summary")
        elif req.menu == Menu.EVENT_SEARCH:
            # HIGHLIGHT: Event Search default-nya preview query dulu.
            # execute=true baru menjalankan query ke MCP.
            if req.execute:
                data = await event_orchestrator.run(req.prompt, plan)
            else:
                data = {"preview": await event_orchestrator.preview(req.prompt, plan)}
            summary = data.get("summary") or "Query preview berhasil dibuat. Review query sebelum Run."
        elif req.menu == Menu.FQL:
            data = await fql_orchestrator.run(req.prompt, plan)
            summary = data.get("summary")
        else:
            raise HTTPException(status_code=400, detail="Menu tidak valid.")

        await audit.write(
            "request_success",
            {
                "request_id": request_id,
                "menu": req.menu,
                "tool": plan.tool,
                "execute": req.execute,
            },
        )

        return APIResponse(
            request_id=request_id,
            menu=req.menu,
            blocked=False,
            message="success",
            plan=plan,
            guardrail=decision,
            summary=summary,
            data=data,
        ).model_dump()

    except Exception as error:
        await audit.write("request_error", {"request_id": request_id, "error": str(error)})
        raise HTTPException(status_code=500, detail=str(error))


@router.post("/api/tool")
async def direct_tool(req: ToolCallRequest) -> dict:
    """
    Direct tool call untuk debug/admin.

    HIGHLIGHT:
    Endpoint ini tetap lewat guardrail. Jangan buat endpoint direct tool yang bebas.
    """
    request_id = audit.new_request_id()
    decision = guardrail.validate_direct_tool(req.menu, req.tool_name, confirmed=req.confirmed)
    if not decision.allowed:
        return {
            "request_id": request_id,
            "blocked": True,
            "message": decision.reason,
            "guardrail": decision.model_dump(),
        }

    try:
        result = await mcp_service.call_tool(req.tool_name, req.arguments)
        return {"request_id": request_id, "blocked": False, "result": result}
    except Exception as error:
        raise HTTPException(status_code=500, detail=str(error))
