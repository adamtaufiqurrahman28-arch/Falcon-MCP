from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from app.core.constants import Menu


class PromptRequest(BaseModel):
    """
    HIGHLIGHT: Semua request UI harus membawa menu.
    Ini fondasi guardrail agar Investigation, Event Search, dan FQL tidak saling bocor.
    """

    menu: Menu
    prompt: str = Field(..., min_length=1)
    execute: bool = False
    confirmed: bool = False
    form_data: Dict[str, Any] = Field(default_factory=dict)


class ToolCallRequest(BaseModel):
    tool_name: str
    arguments: Dict[str, Any] = Field(default_factory=dict)
    menu: Optional[Menu] = None
    confirmed: bool = False


class LLMPlan(BaseModel):
    menu: Menu
    intent: str
    tool: Optional[str] = None
    arguments: Dict[str, Any] = Field(default_factory=dict)
    confidence: Literal["low", "medium", "high"] = "medium"
    requires_enrichment: bool = False
    explanation: str = ""

    # Event Search specific
    generated_query: Optional[str] = None
    time_range: Optional[str] = None
    query_explanation: List[str] = Field(default_factory=list)
    is_manual_query: bool = False

    # FQL specific
    resource_type: Optional[str] = None
    generated_fql: Optional[str] = None


class GuardrailDecision(BaseModel):
    allowed: bool
    reason: str
    suggested_menu: Optional[Menu] = None
    risk_level: Literal["read", "write", "dangerous"] = "read"
    requires_confirmation: bool = False


class MCPResult(BaseModel):
    tool: str
    arguments: Dict[str, Any]
    result: List[Dict[str, Any]] = Field(default_factory=list)


class Observable(BaseModel):
    type: Literal["sha256", "sha1", "md5", "ip", "domain", "url"]
    value: str


class EnrichmentItem(BaseModel):
    observable: Observable
    source: str
    verdict: Literal["benign", "suspicious", "malicious", "unknown"] = "unknown"
    summary: str = ""
    raw: Dict[str, Any] = Field(default_factory=dict)


class InvestigationCase(BaseModel):
    verdict: Literal["benign", "suspicious", "malicious", "inconclusive"] = "inconclusive"
    risk: Literal["low", "medium", "high", "critical"] = "medium"
    confidence: Literal["low", "medium", "high"] = "medium"
    summary: str = ""
    evidence: List[str] = Field(default_factory=list)
    observables: List[Observable] = Field(default_factory=list)
    enrichment: List[EnrichmentItem] = Field(default_factory=list)
    scope_impact: Dict[str, Any] = Field(default_factory=dict)
    recommendations: List[str] = Field(default_factory=list)
    gaps: List[str] = Field(default_factory=list)
    raw: Dict[str, Any] = Field(default_factory=dict)


class APIResponse(BaseModel):
    request_id: str
    menu: Menu
    blocked: bool = False
    message: Optional[str] = None
    plan: Optional[LLMPlan] = None
    guardrail: Optional[GuardrailDecision] = None
    summary: Optional[str] = None
    data: Dict[str, Any] = Field(default_factory=dict)
