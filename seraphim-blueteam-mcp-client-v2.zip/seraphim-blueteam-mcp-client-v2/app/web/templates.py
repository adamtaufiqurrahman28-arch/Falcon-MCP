HTML_TEMPLATE = r"""
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Seraphim BlueTeam MCP Client</title>
  <style>
    :root {
      --navy: #07152f;
      --navy-2: #0b1f45;
      --blue: #155cff;
      --blue-soft: #eaf0ff;
      --bg: #f5f7fb;
      --card: #ffffff;
      --line: #d9e2f3;
      --text: #101828;
      --muted: #667085;
      --success: #027a48;
      --warning: #b54708;
      --danger: #b42318;
      --radius: 20px;
      --shadow: 0 14px 38px rgba(7,21,47,.08);
    }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: var(--bg); color: var(--text); }
    .topbar { background: #fff; border-bottom: 1px solid var(--line); position: sticky; top: 0; z-index: 10; }
    .topbar-inner { max-width: 1180px; margin: 0 auto; padding: 14px 20px; display:flex; justify-content:space-between; align-items:center; gap:16px; }
    .brand { display:flex; align-items:center; gap:12px; }
    .brand img { height:42px; width:auto; }
    .brand strong { display:block; color:var(--navy); font-size:14px; text-transform:uppercase; letter-spacing:.06em; }
    .brand span { color:var(--muted); font-size:12px; }
    .pill { border:1px solid #b7d5ff; background:#f0f6ff; color:#0b4bb3; border-radius:999px; padding:7px 10px; font-weight:800; font-size:12px; white-space:nowrap; }
    main { max-width:1180px; margin:0 auto; padding:24px 20px 54px; }
    .hero { background:linear-gradient(135deg,#fff,#f8fbff 52%,#eef4ff); border:1px solid var(--line); border-radius:28px; padding:26px; box-shadow:var(--shadow); }
    .eyebrow { text-transform:uppercase; letter-spacing:.14em; font-weight:900; color:var(--blue); font-size:12px; margin-bottom:10px; }
    h1 { margin:0; color:var(--navy); font-size:clamp(28px,4.8vw,44px); line-height:1.05; }
    .hero p { color:var(--muted); line-height:1.6; max-width:760px; }
    .menu-grid { display:grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap:16px; margin-top:22px; }
    .menu-card { background:#fff; border:1px solid var(--line); border-radius:var(--radius); padding:18px; box-shadow:0 8px 22px rgba(7,21,47,.04); cursor:pointer; transition:.18s ease; min-height:205px; }
    .menu-card.active, .menu-card:hover { border-color:#9db8f4; box-shadow:var(--shadow); transform: translateY(-2px); }
    .icon { width:42px; height:42px; border-radius:14px; background:var(--blue-soft); color:var(--blue); display:flex; align-items:center; justify-content:center; font-weight:900; margin-bottom:14px; }
    .menu-card h3 { margin:0 0 8px; color:var(--navy); }
    .menu-card p { margin:0; color:var(--muted); line-height:1.5; font-size:14px; }
    .tags { margin-top:14px; display:flex; gap:7px; flex-wrap:wrap; }
    .tag { font-size:11px; border:1px solid #eaecf0; background:#f2f4f7; border-radius:999px; padding:5px 8px; font-weight:800; color:#344054; }
    .tag.green { color:var(--success); background:#ecfdf3; border-color:#abefc6; }
    .tag.orange { color:var(--warning); background:#fffaeb; border-color:#fedf89; }
    .workspace { margin-top:24px; display:grid; grid-template-columns: 360px 1fr; gap:18px; align-items:start; }
    .panel { background:#fff; border:1px solid var(--line); border-radius:var(--radius); box-shadow:0 8px 22px rgba(7,21,47,.04); overflow:hidden; }
    .panel-head { padding:18px 20px; border-bottom:1px solid var(--line); }
    .panel-head h2, .panel-head h3 { margin:0; color:var(--navy); }
    .panel-head p { margin:6px 0 0; color:var(--muted); font-size:13px; line-height:1.45; }
    .panel-body { padding:18px 20px 20px; }
    .guide-list { display:grid; gap:10px; }
    .guide-item { display:flex; gap:10px; color:#344054; font-size:13px; line-height:1.45; }
    .dot { width:8px; height:8px; border-radius:999px; background:var(--blue); margin-top:6px; flex:0 0 auto; }
    .examples { display:grid; gap:8px; margin-top:16px; }
    .example { border:1px solid #e4e7ec; background:#f8fafc; border-radius:12px; padding:10px; font-size:12px; cursor:pointer; line-height:1.35; }
    .example:hover { border-color:#9db8f4; background:#f0f6ff; }
    .input-wrap { display:grid; gap:12px; }
    textarea { width:100%; min-height:120px; border:1px solid #d0d5dd; border-radius:16px; padding:14px; font-size:14px; resize:vertical; outline:none; font-family:inherit; }
    textarea:focus { border-color:#9db8f4; box-shadow:0 0 0 4px rgba(21,92,255,.08); }
    .actions { display:flex; gap:10px; flex-wrap:wrap; }
    button { border:0; border-radius:13px; padding:11px 14px; font-weight:900; cursor:pointer; }
    .primary { background:var(--navy); color:#fff; }
    .secondary { background:#fff; color:var(--navy); border:1px solid var(--line); }
    .danger-soft { background:#fef3f2; color:var(--danger); border:1px solid #fecdca; }
    .result { margin-top:16px; display:grid; gap:14px; }
    .result-card { border:1px solid #e4e7ec; border-radius:16px; background:#fff; overflow:hidden; }
    .result-title { padding:13px 15px; background:#f8fafc; border-bottom:1px solid #e4e7ec; font-weight:900; color:var(--navy); display:flex; justify-content:space-between; gap:12px; }
    .result-content { padding:14px 15px; color:#344054; font-size:13px; line-height:1.55; overflow:auto; }
    pre { margin:0; white-space:pre-wrap; word-break:break-word; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size:12px; }
    .blocked { border-left:4px solid var(--danger); background:#fff8f7; color:#7a271a; padding:12px; border-radius:12px; }
    .flow { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-top:14px; }
    .step { background:#f8fafc; border:1px solid #e4e7ec; border-radius:14px; padding:12px; font-size:12px; color:#475467; }
    .step strong { display:block; color:var(--navy); margin-bottom:4px; }
    .hidden { display:none !important; }
    table { width:100%; border-collapse:collapse; font-size:12px; }
    th, td { text-align:left; padding:8px; border-bottom:1px solid #eaecf0; vertical-align:top; }
    th { color:var(--navy); background:#f8fafc; }
    @media (max-width: 900px) { .menu-grid, .workspace { grid-template-columns:1fr; } main { padding:16px 14px 40px; } .brand img { height:34px; } .brand span { display:none; } .flow { grid-template-columns:1fr 1fr; } }
  </style>
</head>
<body>
<header class="topbar">
  <div class="topbar-inner">
    <div class="brand">
      <img src="/static/img/seraphim-blueteam-logo.png" alt="Seraphim BlueTeam" />
      <div><strong>Seraphim BlueTeam MCP</strong><span>LLM-driven Falcon investigation console</span></div>
    </div>
    <div class="pill" id="healthPill">Checking...</div>
  </div>
</header>

<main>
  <section class="hero">
    <div class="eyebrow">Blue Team MCP Client</div>
    <h1>Pilih workflow, biarkan LLM membuat plan, backend tetap jadi guardrail.</h1>
    <p>UI ini dipisah menjadi Investigation, Event Search, dan FQL Search agar user tidak salah konteks. Setiap request membawa menu context ke backend.</p>
    <div class="menu-grid">
      <div class="menu-card active" data-menu="investigation"><div class="icon">I</div><h3>Investigation Center</h3><p>Detection, IOC extraction, VirusTotal enrichment, verdict, dan recommendation.</p><div class="tags"><span class="tag green">Read-only</span><span class="tag">Detection</span><span class="tag">VT</span></div></div>
      <div class="menu-card" data-menu="event_search"><div class="icon">E</div><h3>Event Search</h3><p>NGSIEM/CQL hunting. Prompt natural language selalu menampilkan generated query.</p><div class="tags"><span class="tag">CQL</span><span class="tag">Preview Query</span></div></div>
      <div class="menu-card" data-menu="fql"><div class="icon">F</div><h3>FQL Search</h3><p>Host, policy, sensor, grouping tag, discover, dan resource Falcon generic.</p><div class="tags"><span class="tag">FQL</span><span class="tag orange">Action Preview</span></div></div>
    </div>
  </section>

  <section class="workspace">
    <aside class="panel">
      <div class="panel-head"><h3 id="guideTitle">Investigation Center</h3><p id="guideSubtitle">Guideline dan contoh prompt.</p></div>
      <div class="panel-body">
        <div class="guide-list" id="guideList"></div>
        <div class="examples" id="examples"></div>
      </div>
    </aside>

    <section class="panel">
      <div class="panel-head"><h2 id="workspaceTitle">Investigation Center</h2><p id="workspaceSubtitle">Masukkan request investigasi. Backend akan memvalidasi menu scope sebelum memanggil MCP.</p></div>
      <div class="panel-body">
        <div class="input-wrap">
          <textarea id="promptInput" placeholder="Contoh: Investigasi detection high severity terbaru"></textarea>
          <div class="actions">
            <button class="primary" id="submitBtn">Generate Plan / Run</button>
            <button class="secondary" id="clearBtn">Clear</button>
          </div>
        </div>
        <div class="flow" id="flowBox"></div>
        <div class="result" id="resultBox"></div>
      </div>
    </section>
  </section>
</main>

<script>
const state = { menu: 'investigation', lastEventPrompt: null, lastEventPlan: null };

const MENU = {
  investigation: {
    title: 'Investigation Center',
    subtitle: 'Detection, IOC extraction, VirusTotal enrichment, verdict, dan recommendation.',
    placeholder: 'Contoh: Investigasi detection high severity terbaru',
    guides: [
      'Gunakan untuk detection, incident, behavior, IOC, hash, IP, domain, atau URL mencurigakan.',
      'Menu ini read-only. FQL generic, policy, tag, RTR, dan containment akan diblok.',
      'Output utama: verdict, risk, confidence, evidence, enrichment, gaps, dan next steps.'
    ],
    examples: [
      'Investigasi detection high severity terbaru',
      'Analisa detection ID ldt:xxxx',
      'Cek hash ini ke VirusTotal: 44d88612fea8a8f36de82e1278abb02f',
      'Cari detection PowerShell mencurigakan dalam 24 jam terakhir'
    ],
    flow: ['Prompt', 'LLM Plan', 'Guardrail', 'MCP + VT + Case']
  },
  event_search: {
    title: 'Event Search',
    subtitle: 'NGSIEM/CQL hunting. Query harus muncul sebelum eksekusi.',
    placeholder: 'Contoh: Cari failed RDP login 7 hari terakhir',
    guides: [
      'Gunakan untuk hunting event/log dengan CQL atau natural language.',
      'Setiap prompt natural language akan menghasilkan Generated Query yang bisa direview dulu.',
      'Action non-event seperti policy/tag/RTR akan diblok.'
    ],
    examples: [
      'Cari failed RDP login 7 hari terakhir',
      'Cari process powershell dengan encoded command',
      '#event_simpleName=/Process/i | groupBy([ComputerName, ImageFileName])',
      'Cari DNS request ke domain mencurigakan dalam 24 jam'
    ],
    flow: ['Prompt/CQL', 'Generated Query', 'Review/Run', 'Event Table']
  },
  fql: {
    title: 'FQL Search',
    subtitle: 'Falcon resource search: host, policy, sensor, tag, discover, spotlight.',
    placeholder: 'Contoh: Cari host Windows Server dengan sensor lama',
    guides: [
      'Gunakan untuk host, policy, sensor, grouping tag, last seen, dan Falcon resource search.',
      'Generated FQL akan ditampilkan agar user bisa belajar dan review.',
      'Write action seperti add tag/update policy harus preview + confirmation, bukan auto execute.'
    ],
    examples: [
      'Cari host Windows Server',
      'Cari host dengan hostname contains FINANCE',
      'Cari sensor version lama',
      'Cari host dengan grouping tag Finance'
    ],
    flow: ['Resource Intent', 'Generated FQL', 'Guardrail', 'Resource Table']
  }
};

function setMenu(menu) {
  state.menu = menu;
  document.querySelectorAll('.menu-card').forEach(card => card.classList.toggle('active', card.dataset.menu === menu));
  const cfg = MENU[menu];
  document.getElementById('guideTitle').textContent = cfg.title;
  document.getElementById('guideSubtitle').textContent = cfg.subtitle;
  document.getElementById('workspaceTitle').textContent = cfg.title;
  document.getElementById('workspaceSubtitle').textContent = cfg.subtitle;
  document.getElementById('promptInput').placeholder = cfg.placeholder;
  document.getElementById('guideList').innerHTML = cfg.guides.map(x => `<div class="guide-item"><span class="dot"></span><span>${escapeHtml(x)}</span></div>`).join('');
  document.getElementById('examples').innerHTML = cfg.examples.map(x => `<div class="example" onclick="fillPrompt('${encodeURIComponent(x)}')">${escapeHtml(x)}</div>`).join('');
  document.getElementById('flowBox').innerHTML = cfg.flow.map((x,i) => `<div class="step"><strong>${i+1}. ${escapeHtml(x)}</strong><span>${stepDesc(menu, i)}</span></div>`).join('');
  clearResult();
}

function stepDesc(menu, i) {
  const desc = {
    investigation: ['User request investigasi', 'LLM pilih intent/tool', 'Menu policy check', 'Build case output'],
    event_search: ['Prompt atau CQL manual', 'LLM generate query', 'User review query', 'MCP NGSIEM result'],
    fql: ['Host/policy/tag intent', 'LLM generate FQL', 'Backend validate scope', 'MCP resource result']
  };
  return desc[menu][i];
}

function fillPrompt(encoded) { document.getElementById('promptInput').value = decodeURIComponent(encoded); }
function clearResult() { document.getElementById('resultBox').innerHTML = ''; }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>'"]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[s])); }
function pretty(obj) { return JSON.stringify(obj, null, 2); }

function card(title, content, right='') {
  return `<div class="result-card"><div class="result-title"><span>${escapeHtml(title)}</span><span>${right}</span></div><div class="result-content">${content}</div></div>`;
}
function pre(obj) { return `<pre>${escapeHtml(typeof obj === 'string' ? obj : pretty(obj))}</pre>`; }

async function submitPrompt(execute=false) {
  const prompt = document.getElementById('promptInput').value.trim();
  if (!prompt) return;
  const resultBox = document.getElementById('resultBox');
  resultBox.innerHTML = card('Loading', 'Menghubungi LLM Planner dan MCP backend...');

  try {
    const res = await fetch('/api/prompt', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ menu: state.menu, prompt, execute })
    });
    const data = await res.json();
    renderResponse(data, prompt);
  } catch (err) {
    resultBox.innerHTML = card('Error', `<div class="blocked">${escapeHtml(err)}</div>`);
  }
}

function renderResponse(data, prompt) {
  const resultBox = document.getElementById('resultBox');
  if (data.blocked) {
    resultBox.innerHTML = card('Blocked by Guardrail', `<div class="blocked">${escapeHtml(data.message)}</div>`) + card('Plan Debug', pre(data.plan));
    return;
  }
  const parts = [];
  parts.push(card('LLM Plan', pre(data.plan)));

  if (data.menu === 'event_search') {
    const preview = data.data?.preview;
    if (preview) {
      parts.push(card('Generated Query Preview', `
        <p><b>Mode:</b> ${escapeHtml(preview.query_mode)}</p>
        <p><b>Time Range:</b> ${escapeHtml(preview.time_range)}</p>
        ${pre(preview.generated_query)}
        <p><b>Explanation:</b></p>
        <ul>${(preview.query_explanation || []).map(x => `<li>${escapeHtml(x)}</li>`).join('')}</ul>
        <div class="actions"><button class="primary" onclick="runEventQuery()">Run Query</button><button class="secondary" onclick="copyText(${JSON.stringify(preview.generated_query || '')})">Copy Query</button></div>
      `));
    }
    if (data.data?.summary) parts.push(card('Summary', escapeHtml(data.data.summary)));
    if (data.data?.table) parts.push(card('Event Table', renderTable(data.data.table)));
    if (data.data?.raw) parts.push(card('Raw JSON', pre(data.data.raw)));
  }

  if (data.menu === 'investigation') {
    const c = data.data?.case;
    if (c) {
      parts.push(card('Case Verdict', `
        <p><b>Verdict:</b> ${escapeHtml(c.verdict)} &nbsp; <b>Risk:</b> ${escapeHtml(c.risk)} &nbsp; <b>Confidence:</b> ${escapeHtml(c.confidence)}</p>
        <p>${escapeHtml(c.summary || '')}</p>
      `));
      parts.push(card('Evidence', `<ul>${(c.evidence || []).map(x => `<li>${escapeHtml(x)}</li>`).join('')}</ul>`));
      parts.push(card('IOC Enrichment', pre(c.enrichment || [])));
      parts.push(card('Recommendations', `<ol>${(c.recommendations || []).map(x => `<li>${escapeHtml(x)}</li>`).join('')}</ol>`));
      parts.push(card('Gaps', `<ul>${(c.gaps || []).map(x => `<li>${escapeHtml(x)}</li>`).join('')}</ul>`));
    }
    parts.push(card('Raw Data', pre(data.data || {})));
  }

  if (data.menu === 'fql') {
    const preview = data.data?.preview;
    if (preview) parts.push(card('Generated FQL Preview', `<p><b>Resource:</b> ${escapeHtml(preview.resource_type)}</p>${pre(preview.generated_fql || '')}<p>${escapeHtml(preview.explanation || '')}</p>`));
    if (data.data?.summary) parts.push(card('Summary', escapeHtml(data.data.summary)));
    if (data.data?.table) parts.push(card('Resource Table', renderTable(data.data.table)));
    if (data.data?.raw) parts.push(card('Raw JSON', pre(data.data.raw)));
  }

  resultBox.innerHTML = parts.join('');
}

async function runEventQuery() { await submitPrompt(true); }
function copyText(text) { navigator.clipboard?.writeText(text); }

function renderTable(rows) {
  if (!Array.isArray(rows) || rows.length === 0) return '<p>Tidak ada row.</p>';
  const keys = Array.from(new Set(rows.slice(0, 10).flatMap(r => Object.keys(r || {})))).slice(0, 8);
  return `<table><thead><tr>${keys.map(k => `<th>${escapeHtml(k)}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,30).map(row => `<tr>${keys.map(k => `<td>${escapeHtml(formatCell(row?.[k]))}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}
function formatCell(value) { if (typeof value === 'object') return JSON.stringify(value); return value ?? ''; }

async function health() {
  try {
    const res = await fetch('/api/health');
    const data = await res.json();
    document.getElementById('healthPill').textContent = data.llm?.ready ? 'LLM Ready' : 'LLM Not Ready';
  } catch { document.getElementById('healthPill').textContent = 'Health Error'; }
}

document.querySelectorAll('.menu-card').forEach(card => card.addEventListener('click', () => setMenu(card.dataset.menu)));
document.getElementById('submitBtn').addEventListener('click', () => submitPrompt(false));
document.getElementById('clearBtn').addEventListener('click', () => { document.getElementById('promptInput').value=''; clearResult(); });
setMenu('investigation');
health();
</script>
</body>
</html>
"""
