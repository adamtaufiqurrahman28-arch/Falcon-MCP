from __future__ import annotations

from enum import StrEnum


class Menu(StrEnum):
    INVESTIGATION = "investigation"
    EVENT_SEARCH = "event_search"
    FQL = "fql"


class Verdict(StrEnum):
    BENIGN = "benign"
    SUSPICIOUS = "suspicious"
    MALICIOUS = "malicious"
    INCONCLUSIVE = "inconclusive"


DANGEROUS_TOOL_KEYWORDS = {
    "delete",
    "remove",
    "update",
    "create",
    "modify",
    "assign",
    "contain",
    "isolate",
    "uninstall",
    "rtr",
    "put",
    "run",
    "execute",
    "policy_update",
    "ioa_create",
}

# HIGHLIGHT: Ini bukan router rule-based.
# Ini hanya policy allow-list agar LLM planner tidak bisa menjalankan tool lintas menu.
MENU_ALLOWED_TOOL_KEYWORDS = {
    Menu.INVESTIGATION: {
        "detection",
        "detections",
        "incident",
        "incidents",
        "behavior",
        "behaviors",
        "ioc",
        "intel",
    },
    Menu.EVENT_SEARCH: {
        "ngsiem",
        "event",
        "events",
        "query",
    },
    Menu.FQL: {
        "host",
        "hosts",
        "policy",
        "policies",
        "sensor",
        "sensorusage",
        "discover",
        "spotlight",
        "tag",
        "tags",
        "firewall",
        "idp",
        "scheduledreports",
    },
}

MENU_BLOCKED_TOOL_KEYWORDS = {
    Menu.INVESTIGATION: {
        "policy",
        "policies",
        "sensorusage",
        "discover",
        "firewall",
        "scheduledreports",
        "ngsiem",
        "event",
        "rtr",
        "host_group",
        "tag",
    },
    Menu.EVENT_SEARCH: {
        "policy",
        "policies",
        "sensorusage",
        "discover",
        "firewall",
        "scheduledreports",
        "rtr",
        "tag",
    },
    Menu.FQL: {
        "rtr",
    },
}
