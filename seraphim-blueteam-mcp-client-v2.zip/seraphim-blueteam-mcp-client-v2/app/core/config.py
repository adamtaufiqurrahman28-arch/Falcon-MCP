from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List

from dotenv import load_dotenv

load_dotenv()


def str_to_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def csv_to_list(value: str | None, default: str = "*") -> List[str]:
    raw = value if value is not None else default
    return [item.strip() for item in raw.split(",") if item.strip()]


@dataclass(frozen=True)
class Settings:
    """
    HIGHLIGHT: Central config.
    Semua secret dan endpoint harus dari .env, bukan hardcoded di source code.
    """

    app_name: str = os.getenv("APP_NAME", "Seraphim BlueTeam MCP Client")
    app_env: str = os.getenv("APP_ENV", "development")
    default_limit: int = int(os.getenv("DEFAULT_LIMIT", "10"))
    cors_allow_origins: List[str] = None  # type: ignore[assignment]

    mcp_server_url: str = os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000/mcp")

    llm_enabled: bool = str_to_bool(os.getenv("LLM_ENABLED"), False)
    llm_api_key: str | None = os.getenv("LLM_API_KEY") or os.getenv("OPENAI_API_KEY")
    llm_base_url: str = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
    llm_model: str = os.getenv("LLM_MODEL", os.getenv("OPENAI_MODEL", "gpt-4o-mini"))

    vt_enabled: bool = str_to_bool(os.getenv("VT_ENABLED"), False)
    vt_api_key: str | None = os.getenv("VT_API_KEY")

    redis_url: str | None = os.getenv("REDIS_URL")
    audit_enabled: bool = str_to_bool(os.getenv("AUDIT_ENABLED"), False)
    audit_stream_key: str = os.getenv("AUDIT_STREAM_KEY", "seraphim:mcp:audit")
    audit_max_len: int = int(os.getenv("AUDIT_MAX_LEN", "1000"))

    def __post_init__(self) -> None:
        object.__setattr__(self, "cors_allow_origins", csv_to_list(os.getenv("CORS_ALLOW_ORIGINS"), "*"))


settings = Settings()
