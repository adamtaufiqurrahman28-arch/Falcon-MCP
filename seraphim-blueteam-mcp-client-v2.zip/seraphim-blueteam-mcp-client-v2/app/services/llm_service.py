from __future__ import annotations

from typing import Any, Dict

from app.core.config import settings


class LLMService:
    """
    Thin wrapper untuk OpenAI-compatible API.

    HIGHLIGHT:
    - Project ini LLM-first, bukan rule-based router.
    - Tapi LLM hanya planner/summarizer. Eksekusi tetap dikunci oleh backend guardrail.
    - Import OpenAI dibuat lazy agar app bisa start dan memberi error jelas jika dependency belum di-install.
    """

    def __init__(self) -> None:
        self.enabled = settings.llm_enabled
        self.api_key = settings.llm_api_key
        self.base_url = settings.llm_base_url
        self.model = settings.llm_model
        self._client = None

        if self.enabled and self.api_key:
            self._client = self._build_client()

    def _build_client(self):
        try:
            from openai import OpenAI
        except Exception as error:
            raise RuntimeError("Dependency OpenAI belum tersedia. Jalankan: pip install -r requirements.txt") from error
        return OpenAI(api_key=self.api_key, base_url=self.base_url)

    def is_ready(self) -> bool:
        return bool(self.enabled and self._client and self.api_key)

    def metadata(self) -> Dict[str, Any]:
        return {
            "enabled": self.enabled,
            "ready": self.is_ready(),
            "base_url": self.base_url,
            "model": self.model,
        }

    def chat_json(self, system_prompt: str, user_prompt: str, temperature: float = 0.1) -> str:
        if not self.is_ready() or self._client is None:
            raise RuntimeError("LLM belum siap. Set LLM_ENABLED=true dan LLM_API_KEY di .env.")

        response = self._client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
            response_format={"type": "json_object"},
        )
        return response.choices[0].message.content or "{}"

    def chat_text(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        if not self.is_ready() or self._client is None:
            raise RuntimeError("LLM belum siap. Set LLM_ENABLED=true dan LLM_API_KEY di .env.")

        response = self._client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content or ""
