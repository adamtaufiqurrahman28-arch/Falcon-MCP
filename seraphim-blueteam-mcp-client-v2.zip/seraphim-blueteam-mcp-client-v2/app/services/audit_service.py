from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List

from app.core.config import settings

try:
    import redis.asyncio as redis
except Exception:  # pragma: no cover
    redis = None  # type: ignore


class AuditService:
    """
    Optional Redis audit trail.
    HIGHLIGHT: Security tool harus punya jejak request, minimal request_id + menu + tool + blocked/allowed.
    """

    def __init__(self) -> None:
        self.enabled = bool(settings.audit_enabled and settings.redis_url and redis)
        self.stream_key = settings.audit_stream_key
        self._client = redis.from_url(settings.redis_url) if self.enabled else None

    def new_request_id(self) -> str:
        return str(uuid.uuid4())

    async def write(self, event_type: str, payload: Dict[str, Any]) -> None:
        if not self.enabled or self._client is None:
            return
        event = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "event_type": event_type,
            "payload": json.dumps(payload, ensure_ascii=False, default=str),
        }
        await self._client.xadd(self.stream_key, event, maxlen=settings.audit_max_len, approximate=True)

    async def recent(self, limit: int = 25) -> List[Dict[str, Any]]:
        if not self.enabled or self._client is None:
            return []
        rows = await self._client.xrevrange(self.stream_key, count=limit)
        out: List[Dict[str, Any]] = []
        for _, data in rows:
            decoded = {k.decode() if isinstance(k, bytes) else k: v.decode() if isinstance(v, bytes) else v for k, v in data.items()}
            try:
                decoded["payload"] = json.loads(decoded.get("payload", "{}"))
            except Exception:
                pass
            out.append(decoded)
        return out
