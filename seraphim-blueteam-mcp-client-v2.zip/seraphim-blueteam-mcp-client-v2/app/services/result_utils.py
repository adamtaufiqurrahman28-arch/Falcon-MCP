from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List


def safe_json_dumps(data: Any, limit: int = 12000) -> str:
    try:
        text = json.dumps(data, ensure_ascii=False, indent=2, default=str)
    except Exception:
        text = str(data)
    if len(text) > limit:
        return text[:limit] + "\n... [truncated]"
    return text


def flatten_mcp_rows(rows: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    HIGHLIGHT: MCP result sering nested. Fungsi ini bikin UI dan LLM summary lebih stabil.
    """
    flattened: List[Dict[str, Any]] = []
    for row in rows:
        data = row.get("data", row)
        if isinstance(data, list):
            for item in data:
                flattened.append(item if isinstance(item, dict) else {"value": item})
        elif isinstance(data, dict):
            # Beberapa Falcon MCP response membungkus data di key resources/items/results.
            for key in ("resources", "items", "results", "detections", "hosts", "events"):
                if isinstance(data.get(key), list):
                    for item in data[key]:
                        flattened.append(item if isinstance(item, dict) else {"value": item})
                    break
            else:
                flattened.append(data)
        else:
            flattened.append({"value": data})
    return flattened


def short_preview(data: Any, max_items: int = 8) -> Any:
    if isinstance(data, list):
        return data[:max_items]
    return data
