from __future__ import annotations

import json
from typing import Any, Dict, List

from app.core.config import settings


class MCPService:
    """
    HIGHLIGHT: Satu-satunya layer yang berkomunikasi langsung ke Falcon MCP Server.
    Jangan taruh logic Investigation/Event/FQL di sini. Logic workflow ada di orchestrator.

    Catatan belajar:
    Import library MCP dibuat lazy di dalam method, supaya aplikasi tetap bisa start dan menampilkan
    error yang jelas jika dependency MCP belum di-install.
    """

    def __init__(self, server_url: str | None = None):
        self.server_url = server_url or settings.mcp_server_url

    async def list_tools(self) -> List[Dict[str, Any]]:
        ClientSession, streamable_http_client = self._load_mcp_client()
        async with streamable_http_client(self.server_url) as (read_stream, write_stream, _):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()
                tools = await session.list_tools()
                return [
                    {
                        "name": tool.name,
                        "description": tool.description or "-",
                        "input_schema": getattr(tool, "inputSchema", None) or getattr(tool, "input_schema", None),
                    }
                    for tool in tools.tools
                ]

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        ClientSession, streamable_http_client = self._load_mcp_client()
        async with streamable_http_client(self.server_url) as (read_stream, write_stream, _):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()
                result = await session.call_tool(tool_name, arguments)
                return {
                    "tool": tool_name,
                    "arguments": arguments,
                    "result": self._parse_result(result),
                }

    def _load_mcp_client(self):
        try:
            from mcp import ClientSession
            from mcp.client.streamable_http import streamable_http_client
        except Exception as error:
            raise RuntimeError("Dependency MCP belum tersedia. Jalankan: pip install -r requirements.txt") from error
        return ClientSession, streamable_http_client

    def _parse_result(self, result: Any) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        for content in result.content:
            if hasattr(content, "text"):
                text = content.text
                try:
                    rows.append({"type": "json", "data": json.loads(text)})
                except Exception:
                    rows.append({"type": "text", "data": text})
            else:
                rows.append({"type": "raw", "data": str(content)})
        return rows
