from __future__ import annotations

import json
from typing import Any, Dict, List

from app.core.constants import Menu
from app.models.schemas import LLMPlan
from app.services.llm_service import LLMService
from app.services.result_utils import safe_json_dumps


class PlannerService:
    """
    LLM Planner menghasilkan structured plan.

    HIGHLIGHT UNTUK BELAJAR:
    Di sini LLM dipakai untuk memahami maksud user, bukan untuk langsung eksekusi.
    Setelah plan dibuat, GuardrailService tetap wajib mengecek apakah tool boleh dijalankan.
    """

    def __init__(self, llm_service: LLMService) -> None:
        self.llm = llm_service

    def build_plan(self, menu: Menu, prompt: str, tools: List[Dict[str, Any]], form_data: Dict[str, Any] | None = None) -> LLMPlan:
        # HIGHLIGHT: Manual query detection bukan rule-based router.
        # Ini hanya UX agar user yang sudah menulis CQL/FQL tidak dipaksa regenerate oleh LLM.
        manual_plan = self._manual_query_plan(menu, prompt, form_data or {})
        if manual_plan:
            return manual_plan

        system_prompt = self._system_prompt(menu)
        user_prompt = safe_json_dumps(
            {
                "selected_menu": menu,
                "user_prompt": prompt,
                "form_data": form_data or {},
                "available_mcp_tools": self._compact_tools(tools),
                "required_output_schema": {
                    "menu": str(menu),
                    "intent": "short_snake_case_intent",
                    "tool": "one of available_mcp_tools.name or null",
                    "arguments": "object arguments for selected MCP tool",
                    "confidence": "low|medium|high",
                    "requires_enrichment": "boolean",
                    "explanation": "short reason",
                    "generated_query": "for event_search only",
                    "time_range": "for event_search only",
                    "query_explanation": "array of short explanations for generated query",
                    "resource_type": "for fql only",
                    "generated_fql": "for fql only",
                },
            }
        )

        raw = self.llm.chat_json(system_prompt, user_prompt)
        data = self._safe_json(raw)
        data.setdefault("menu", menu)
        return LLMPlan.model_validate(data)

    def summarize(self, menu: Menu, prompt: str, context: Dict[str, Any]) -> str:
        system_prompt = """
You are Seraphim BlueTeam MCP summarizer.
Write concise Indonesian output for a security analyst.
Never invent evidence. If evidence is missing, state it as a gap.
Prefer structured bullets.
""".strip()
        user_prompt = safe_json_dumps({"menu": menu, "prompt": prompt, "context": context})
        return self.llm.chat_text(system_prompt, user_prompt, temperature=0.2)

    def _system_prompt(self, menu: Menu) -> str:
        base = """
You are the LLM Planner for Seraphim BlueTeam MCP Client.
Return JSON only.
Your job: choose intent, MCP tool, and arguments. Do not execute anything.
Backend guardrails will validate your plan.
Never choose destructive/write tools unless user explicitly asks and menu supports it; prefer read-only.
""".strip()

        if menu == Menu.INVESTIGATION:
            return base + """

MENU CONTEXT: Investigation Center
Allowed intent: detection/incident/behavior/IOC investigation, evidence extraction, IOC enrichment recommendation.
Blocked intent: generic FQL host/policy search, NGSIEM manual query, policy/tag changes, RTR, containment.
If user asks host/policy/tag generic search, set tool=null and intent='wrong_menu_fql'.
For detection candidate search, prefer detection or incident MCP tools.
Set requires_enrichment=true if prompt or likely result involves hash, IP, domain, or URL.
"""
        if menu == Menu.EVENT_SEARCH:
            return base + """

MENU CONTEXT: Event Search
Allowed intent: NGSIEM/CQL event hunting only.
Every natural-language request must produce generated_query, time_range, and query_explanation.
Do not hide the generated query. User must be able to review/edit/copy before execution.
Blocked intent: FQL host/policy search, tag changes, RTR, containment.
"""
        return base + """

MENU CONTEXT: FQL Search
Allowed intent: Falcon resource search such as hosts, policies, sensors, grouping tags, discover assets, spotlight.
You may generate generated_fql and choose matching MCP tool.
For write actions such as add tag or update policy, do not execute silently; mark intent as action_preview and explain confirmation needed.
Blocked intent: RTR, destructive execution, generic event hunting.
"""

    def _compact_tools(self, tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        compacted = []
        for tool in tools[:120]:
            compacted.append(
                {
                    "name": tool.get("name"),
                    "description": (tool.get("description") or "")[:240],
                    "input_schema": tool.get("input_schema") or {},
                }
            )
        return compacted

    def _safe_json(self, raw: str) -> Dict[str, Any]:
        try:
            return json.loads(raw)
        except Exception:
            start = raw.find("{")
            end = raw.rfind("}")
            if start >= 0 and end > start:
                return json.loads(raw[start : end + 1])
            raise

    def _manual_query_plan(self, menu: Menu, prompt: str, form_data: Dict[str, Any]) -> LLMPlan | None:
        stripped = prompt.strip()
        if menu == Menu.EVENT_SEARCH and (stripped.startswith("#") or "|" in stripped):
            return LLMPlan(
                menu=menu,
                intent="manual_cql_query",
                tool=form_data.get("tool") or "falcon_search_ngsiem",
                arguments={"query": stripped},
                confidence="high",
                generated_query=stripped,
                query_explanation=["User sudah memasukkan CQL/manual query, sehingga sistem tidak regenerate query."],
                is_manual_query=True,
            )
        if menu == Menu.FQL and any(token in stripped for token in (":", "'", "last_seen", "hostname", "platform_name")):
            return LLMPlan(
                menu=menu,
                intent="manual_fql_search",
                tool=form_data.get("tool"),
                arguments={"filter": stripped, **form_data},
                confidence="medium",
                generated_fql=stripped,
                resource_type=form_data.get("resource_type"),
                is_manual_query=True,
            )
        return None
