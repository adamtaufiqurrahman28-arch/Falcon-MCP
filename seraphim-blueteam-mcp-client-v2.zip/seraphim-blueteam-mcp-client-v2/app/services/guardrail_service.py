from __future__ import annotations

from typing import Dict, Optional

from app.core.constants import DANGEROUS_TOOL_KEYWORDS, MENU_ALLOWED_TOOL_KEYWORDS, MENU_BLOCKED_TOOL_KEYWORDS, Menu
from app.models.schemas import GuardrailDecision, LLMPlan


class GuardrailService:
    """
    HIGHLIGHT TERPENTING:
    LLM boleh memilih tool, tapi backend guardrail yang menentukan boleh eksekusi atau tidak.

    Ini menjawab kebutuhan:
    - Investigation tidak boleh dipakai untuk FQL generic.
    - Event Search tidak boleh dipakai untuk policy/tag action.
    - FQL action harus preview/confirmation, bukan auto execute.
    """

    def validate_plan(self, plan: LLMPlan, confirmed: bool = False) -> GuardrailDecision:
        tool = (plan.tool or "").lower()
        intent = (plan.intent or "").lower()
        combined = f"{tool} {intent}"

        if not plan.tool and intent.startswith("wrong_menu"):
            return GuardrailDecision(
                allowed=False,
                reason=self._wrong_menu_reason(plan),
                suggested_menu=self._suggested_menu(intent),
            )

        if self._is_dangerous(combined):
            if confirmed:
                # V0.1 tetap conservative: FQL write action boleh dibuka nanti setelah action preview matang.
                return GuardrailDecision(
                    allowed=False,
                    reason="Write/destructive action belum diaktifkan pada v0.1. Gunakan preview-only terlebih dahulu.",
                    risk_level="dangerous",
                    requires_confirmation=True,
                )
            return GuardrailDecision(
                allowed=False,
                reason="Request mengarah ke action berisiko/write/destructive. V0.1 hanya read-only atau preview.",
                risk_level="dangerous",
                requires_confirmation=True,
            )

        blocked_keywords = MENU_BLOCKED_TOOL_KEYWORDS.get(plan.menu, set())
        if any(keyword in combined for keyword in blocked_keywords):
            return GuardrailDecision(
                allowed=False,
                reason=self._blocked_reason(plan.menu),
                suggested_menu=self._suggest_menu_by_keywords(combined),
            )

        allowed_keywords = MENU_ALLOWED_TOOL_KEYWORDS.get(plan.menu, set())
        if plan.tool and allowed_keywords and not any(keyword in tool for keyword in allowed_keywords):
            return GuardrailDecision(
                allowed=False,
                reason=f"Tool '{plan.tool}' tidak masuk allow-list untuk menu {plan.menu}.",
                suggested_menu=self._suggest_menu_by_keywords(combined),
            )

        return GuardrailDecision(allowed=True, reason="Plan valid untuk menu yang dipilih.")

    def validate_direct_tool(self, menu: Optional[Menu], tool_name: str, confirmed: bool = False) -> GuardrailDecision:
        fake_plan = LLMPlan(menu=menu or Menu.FQL, intent="direct_tool_call", tool=tool_name, arguments={})
        return self.validate_plan(fake_plan, confirmed=confirmed)

    def _is_dangerous(self, text: str) -> bool:
        return any(keyword in text for keyword in DANGEROUS_TOOL_KEYWORDS)

    def _wrong_menu_reason(self, plan: LLMPlan) -> str:
        if plan.menu == Menu.INVESTIGATION:
            return "Request diblok. Menu Investigation hanya untuk detection/incident/IOC investigation. Gunakan FQL Search untuk host, policy, sensor, dan grouping tag."
        if plan.menu == Menu.EVENT_SEARCH:
            return "Request diblok. Menu Event Search hanya untuk NGSIEM/CQL event hunting. Gunakan FQL Search untuk host/policy/resource search."
        return "Request diblok karena intent tidak sesuai dengan menu yang dipilih."

    def _blocked_reason(self, menu: Menu) -> str:
        if menu == Menu.INVESTIGATION:
            return "Request diblok. Menu Investigation hanya mendukung detection/incident/IOC investigation, bukan FQL/Event Search/action."
        if menu == Menu.EVENT_SEARCH:
            return "Request diblok. Menu Event Search hanya mendukung NGSIEM/CQL event hunting."
        return "Request diblok oleh policy menu."

    def _suggested_menu(self, intent: str) -> Optional[Menu]:
        if "fql" in intent or "host" in intent or "policy" in intent:
            return Menu.FQL
        if "event" in intent or "ngsiem" in intent:
            return Menu.EVENT_SEARCH
        if "invest" in intent or "detection" in intent:
            return Menu.INVESTIGATION
        return None

    def _suggest_menu_by_keywords(self, text: str) -> Optional[Menu]:
        mapping: Dict[Menu, set[str]] = {
            Menu.INVESTIGATION: {"detection", "incident", "ioc", "intel", "behavior"},
            Menu.EVENT_SEARCH: {"ngsiem", "event", "query", "cql"},
            Menu.FQL: {"host", "policy", "sensor", "tag", "discover", "spotlight"},
        }
        for menu, keywords in mapping.items():
            if any(keyword in text for keyword in keywords):
                return menu
        return None
