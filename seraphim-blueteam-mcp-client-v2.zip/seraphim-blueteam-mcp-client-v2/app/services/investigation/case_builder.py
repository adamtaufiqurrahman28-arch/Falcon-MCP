from __future__ import annotations

from typing import Any, Dict, List

from app.models.schemas import EnrichmentItem, InvestigationCase, Observable
from app.services.result_utils import flatten_mcp_rows


class InvestigationCaseBuilder:
    """
    HIGHLIGHT: Output Investigation dibuat schema tetap.
    Ini membuat UI stabil dan tidak bergantung pada format jawaban bebas dari LLM.
    """

    def build(
        self,
        prompt: str,
        mcp_response: Dict[str, Any],
        observables: List[Observable],
        enrichment: List[EnrichmentItem],
        ai_summary: str | None = None,
    ) -> InvestigationCase:
        rows = flatten_mcp_rows(mcp_response.get("result", []))
        evidence = self._evidence_from_rows(rows)
        verdict, risk, confidence = self._score(enrichment, evidence)

        recommendations = self._recommendations(verdict, enrichment, evidence)
        gaps = self._gaps(rows, observables)

        summary = ai_summary or self._default_summary(prompt, verdict, risk, len(rows), len(observables), len(enrichment))

        return InvestigationCase(
            verdict=verdict,
            risk=risk,
            confidence=confidence,
            summary=summary,
            evidence=evidence,
            observables=observables,
            enrichment=enrichment,
            scope_impact={
                "result_rows": len(rows),
                "observable_count": len(observables),
                "enriched_count": len(enrichment),
            },
            recommendations=recommendations,
            gaps=gaps,
            raw={"mcp_response": mcp_response, "flattened_rows_preview": rows[:10]},
        )

    def _evidence_from_rows(self, rows: List[Dict[str, Any]]) -> List[str]:
        evidence: List[str] = []
        interesting_keys = [
            "name",
            "detection_name",
            "severity",
            "status",
            "hostname",
            "device_name",
            "ComputerName",
            "user_name",
            "UserName",
            "CommandLine",
            "ImageFileName",
            "sha256",
            "SHA256HashData",
        ]
        for row in rows[:8]:
            parts = []
            for key in interesting_keys:
                value = row.get(key)
                if value:
                    parts.append(f"{key}={value}")
            if parts:
                evidence.append("; ".join(parts)[:600])
        if not evidence and rows:
            evidence.append("MCP mengembalikan data, tetapi field evidence utama belum terpetakan.")
        return evidence[:12]

    def _score(self, enrichment: List[EnrichmentItem], evidence: List[str]) -> tuple[str, str, str]:
        malicious = sum(1 for item in enrichment if item.verdict == "malicious")
        suspicious = sum(1 for item in enrichment if item.verdict == "suspicious")
        text = " ".join(evidence).lower()

        suspicious_patterns = ["powershell", "encoded", "mimikatz", "credential", "rundll32", "regsvr32", "wscript", "cscript"]
        pattern_hit = any(pattern in text for pattern in suspicious_patterns)

        if malicious > 0:
            return "malicious", "critical", "high"
        if suspicious > 0 and pattern_hit:
            return "suspicious", "high", "medium"
        if suspicious > 0 or pattern_hit:
            return "suspicious", "medium", "medium"
        if evidence:
            return "inconclusive", "medium", "low"
        return "inconclusive", "low", "low"

    def _recommendations(self, verdict: str, enrichment: List[EnrichmentItem], evidence: List[str]) -> List[str]:
        recs = [
            "Review full detection detail dan command line sebelum mengambil keputusan containment.",
            "Cari IOC yang sama di seluruh environment untuk memastikan scope impact.",
            "Validasi parent process dan child process di sekitar waktu detection.",
        ]
        if any(item.verdict in {"malicious", "suspicious"} for item in enrichment):
            recs.append("Prioritaskan host yang memiliki IOC dengan reputasi malicious/suspicious di VirusTotal.")
        if verdict in {"malicious", "suspicious"}:
            recs.append("Pertimbangkan isolate host jika aktivitas masih aktif dan business impact dapat diterima.")
        if "powershell" in " ".join(evidence).lower():
            recs.append("Review PowerShell Operational Log dan cari encoded command / suspicious script block.")
        return recs

    def _gaps(self, rows: List[Dict[str, Any]], observables: List[Observable]) -> List[str]:
        gaps = []
        if not rows:
            gaps.append("Tidak ada row result dari MCP untuk dianalisis.")
        if not observables:
            gaps.append("Tidak ditemukan IOC eksplisit seperti hash, IP publik, domain, atau URL pada hasil awal.")
        if rows and not any("CommandLine" in row or "cmdline" in str(row).lower() for row in rows):
            gaps.append("Command line tidak terlihat jelas pada result awal; perlu query detail/timeline tambahan.")
        return gaps

    def _default_summary(self, prompt: str, verdict: str, risk: str, row_count: int, ioc_count: int, enrichment_count: int) -> str:
        return (
            f"Investigation selesai untuk prompt: '{prompt}'. Verdict sementara: {verdict}, "
            f"risk: {risk}. MCP rows={row_count}, IOC ditemukan={ioc_count}, enrichment={enrichment_count}."
        )
