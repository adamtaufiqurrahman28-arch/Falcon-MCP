from __future__ import annotations

import base64
from typing import Any, Dict, List

import httpx

from app.core.config import settings
from app.models.schemas import EnrichmentItem, Observable


class VirusTotalService:
    """
    VirusTotal enrichment untuk menu Investigation.

    HIGHLIGHT:
    - Jangan kirim semua data sensitif ke external API.
    - Enrich hanya IOC: hash, public IP, domain, URL.
    - URL submit/scanning otomatis sebaiknya dihindari pada v0.1; lookup existing report saja.
    """

    BASE_URL = "https://www.virustotal.com/api/v3"

    def __init__(self) -> None:
        self.enabled = settings.vt_enabled
        self.api_key = settings.vt_api_key

    def is_ready(self) -> bool:
        return bool(self.enabled and self.api_key)

    async def enrich_many(self, observables: List[Observable]) -> List[EnrichmentItem]:
        if not self.is_ready():
            return []
        results: List[EnrichmentItem] = []
        async with httpx.AsyncClient(timeout=20) as client:
            for obs in observables[:20]:
                try:
                    item = await self.lookup(client, obs)
                    results.append(item)
                except Exception as error:
                    results.append(
                        EnrichmentItem(
                            observable=obs,
                            source="virustotal",
                            verdict="unknown",
                            summary=f"VT lookup gagal: {error}",
                            raw={"error": str(error)},
                        )
                    )
        return results

    async def lookup(self, client: httpx.AsyncClient, observable: Observable) -> EnrichmentItem:
        endpoint = self._endpoint(observable)
        headers = {"x-apikey": self.api_key or ""}
        response = await client.get(f"{self.BASE_URL}/{endpoint}", headers=headers)
        if response.status_code == 404:
            return EnrichmentItem(
                observable=observable,
                source="virustotal",
                verdict="unknown",
                summary="Tidak ada report VirusTotal untuk observable ini.",
                raw={"status_code": 404},
            )
        response.raise_for_status()
        raw = response.json()
        verdict, summary = self._summarize(raw)
        return EnrichmentItem(
            observable=observable,
            source="virustotal",
            verdict=verdict,
            summary=summary,
            raw=raw,
        )

    def _endpoint(self, observable: Observable) -> str:
        if observable.type in {"sha256", "sha1", "md5"}:
            return f"files/{observable.value}"
        if observable.type == "ip":
            return f"ip_addresses/{observable.value}"
        if observable.type == "domain":
            return f"domains/{observable.value}"
        if observable.type == "url":
            # VT URL lookup uses base64url without padding.
            encoded = base64.urlsafe_b64encode(observable.value.encode()).decode().strip("=")
            return f"urls/{encoded}"
        raise ValueError(f"Unsupported observable type: {observable.type}")

    def _summarize(self, raw: Dict[str, Any]) -> tuple[str, str]:
        attrs = raw.get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {}) or {}
        malicious = int(stats.get("malicious", 0) or 0)
        suspicious = int(stats.get("suspicious", 0) or 0)
        harmless = int(stats.get("harmless", 0) or 0)

        if malicious >= 5:
            verdict = "malicious"
        elif malicious > 0 or suspicious > 0:
            verdict = "suspicious"
        elif harmless > 0:
            verdict = "benign"
        else:
            verdict = "unknown"

        summary = f"VT stats: malicious={malicious}, suspicious={suspicious}, harmless={harmless}."
        return verdict, summary
