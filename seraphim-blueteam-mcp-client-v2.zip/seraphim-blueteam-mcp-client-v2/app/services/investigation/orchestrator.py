from __future__ import annotations

from typing import Any, Dict

from app.core.constants import Menu
from app.models.schemas import LLMPlan
from app.services.investigation.case_builder import InvestigationCaseBuilder
from app.services.investigation.ioc_extractor import IOCExtractor
from app.services.investigation.virustotal_service import VirusTotalService
from app.services.mcp_service import MCPService
from app.services.planner_service import PlannerService
from app.services.result_utils import safe_json_dumps


class InvestigationOrchestrator:
    """
    HIGHLIGHT: Inilah layer yang membuat menu Investigation bukan sekadar prompt context.
    Flow blue team dipaksa di backend: MCP -> IOC extractor -> VT enrichment -> case builder -> AI summary.
    """

    def __init__(
        self,
        mcp_service: MCPService,
        planner: PlannerService,
        vt_service: VirusTotalService,
    ) -> None:
        self.mcp = mcp_service
        self.planner = planner
        self.extractor = IOCExtractor()
        self.vt = vt_service
        self.case_builder = InvestigationCaseBuilder()

    async def run(self, prompt: str, plan: LLMPlan) -> Dict[str, Any]:
        if not plan.tool:
            return {"message": "LLM planner tidak memilih MCP tool untuk investigation.", "case": None}

        mcp_response = await self.mcp.call_tool(plan.tool, plan.arguments)
        observables = self.extractor.extract(mcp_response)
        enrichment = await self.vt.enrich_many(observables) if observables else []

        summary_context = {
            "prompt": prompt,
            "plan": plan.model_dump(),
            "observables": [item.model_dump() for item in observables],
            "enrichment": [item.model_dump() for item in enrichment],
            "mcp_preview": safe_json_dumps(mcp_response, limit=8000),
        }
        ai_summary = None
        try:
            ai_summary = self.planner.summarize(Menu.INVESTIGATION, prompt, summary_context)
        except Exception:
            # Summary AI gagal tidak boleh menggagalkan investigation case.
            ai_summary = None

        case = self.case_builder.build(prompt, mcp_response, observables, enrichment, ai_summary=ai_summary)
        return {
            "case": case.model_dump(),
            "mcp_response": mcp_response,
            "observables": [item.model_dump() for item in observables],
            "enrichment": [item.model_dump() for item in enrichment],
            "vt_ready": self.vt.is_ready(),
        }
