from __future__ import annotations

import re
from typing import Any, Iterable, List, Set

from app.models.schemas import Observable
from app.services.result_utils import safe_json_dumps


class IOCExtractor:
    """
    HIGHLIGHT: IOC extraction jangan diserahkan penuh ke AI.
    Regex deterministic lebih aman untuk hash, IP, domain, dan URL.
    """

    SHA256_RE = re.compile(r"\b[a-fA-F0-9]{64}\b")
    SHA1_RE = re.compile(r"\b[a-fA-F0-9]{40}\b")
    MD5_RE = re.compile(r"\b[a-fA-F0-9]{32}\b")
    IPV4_RE = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")
    URL_RE = re.compile(r"\bhttps?://[^\s'\"<>]+", re.IGNORECASE)
    DOMAIN_RE = re.compile(r"\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b")

    PRIVATE_PREFIXES = ("10.", "127.", "169.254.", "172.16.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.", "192.168.")

    def extract(self, data: Any) -> List[Observable]:
        text = safe_json_dumps(data, limit=100_000)
        observables: List[Observable] = []
        seen: Set[str] = set()

        def add(type_: str, value: str) -> None:
            key = f"{type_}:{value.lower()}"
            if key in seen:
                return
            seen.add(key)
            observables.append(Observable(type=type_, value=value))  # type: ignore[arg-type]

        for value in self.SHA256_RE.findall(text):
            add("sha256", value.lower())
        for value in self.SHA1_RE.findall(text):
            add("sha1", value.lower())
        for value in self.MD5_RE.findall(text):
            add("md5", value.lower())
        for value in self.URL_RE.findall(text):
            add("url", value.rstrip(".,)];"))
        for value in self.IPV4_RE.findall(text):
            if not value.startswith(self.PRIVATE_PREFIXES):
                add("ip", value)
        for value in self.DOMAIN_RE.findall(text):
            lower = value.lower().strip(".")
            if self._looks_like_domain(lower):
                add("domain", lower)

        return observables[:50]

    def _looks_like_domain(self, value: str) -> bool:
        noisy_suffix = ("exe", "dll", "json", "local", "internal", "corp")
        if value.endswith(noisy_suffix):
            return False
        if any(value.startswith(prefix) for prefix in ("http.", "https.")):
            return False
        return "." in value and not value.replace(".", "").isdigit()
