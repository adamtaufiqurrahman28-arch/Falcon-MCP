from __future__ import annotations

from app.models.schemas import LLMPlan


class FQLBuilder:
    """
    HIGHLIGHT: FQL menu difokuskan untuk Falcon resource search.
    generated_fql ditampilkan supaya user bisa belajar dan review filter yang dibuat AI.
    """

    def preview(self, plan: LLMPlan, prompt: str) -> dict:
        generated_fql = plan.generated_fql or plan.arguments.get("filter") or plan.arguments.get("fql") or ""
        return {
            "user_prompt": prompt,
            "resource_type": plan.resource_type or plan.arguments.get("resource_type") or "generic",
            "generated_fql": generated_fql,
            "explanation": plan.explanation or "FQL dibuat oleh LLM planner berdasarkan prompt user.",
        }
