from __future__ import annotations

from typing import Any, Dict

from app.core.constants import Menu
from app.models.schemas import LLMPlan
from app.services.fql.fql_builder import FQLBuilder
from app.services.mcp_service import MCPService
from app.services.planner_service import PlannerService
from app.services.result_utils import flatten_mcp_rows


class FQLOrchestrator:
    """
    HIGHLIGHT: FQL Search berbeda dari Event Search.
    Di sini user mencari Falcon resources: hosts, policy, sensor, tags, discover, spotlight.
    """

    def __init__(self, mcp_service: MCPService, planner: PlannerService) -> None:
        self.mcp = mcp_service
        self.planner = planner
        self.builder = FQLBuilder()

    async def run(self, prompt: str, plan: LLMPlan) -> Dict[str, Any]:
        preview = self.builder.preview(plan, prompt)
        if not plan.tool:
            return {"preview": preview, "error": "LLM planner belum memilih MCP tool untuk FQL Search."}

        arguments = dict(plan.arguments or {})
        if preview.get("generated_fql"):
            arguments.setdefault("filter", preview["generated_fql"])

        mcp_response = await self.mcp.call_tool(plan.tool, arguments)
        rows = flatten_mcp_rows(mcp_response.get("result", []))

        summary = None
        try:
            summary = self.planner.summarize(
                Menu.FQL,
                prompt,
                {"preview": preview, "row_count": len(rows), "rows_preview": rows[:20]},
            )
        except Exception:
            summary = f"FQL search selesai. Total parsed rows: {len(rows)}."

        return {
            "preview": preview,
            "executed_tool": plan.tool,
            "executed_arguments": arguments,
            "summary": summary,
            "table": rows[:100],
            "raw": mcp_response,
        }
