from __future__ import annotations

from app.models.schemas import LLMPlan


class CQLBuilder:
    """
    HIGHLIGHT: Event Search harus selalu menampilkan query.
    Class ini memastikan generated/manual query tersedia sebelum execute.
    """

    def preview(self, plan: LLMPlan, prompt: str) -> dict:
        query = plan.generated_query or plan.arguments.get("query") or ""
        return {
            "user_prompt": prompt,
            "query_mode": "manual" if plan.is_manual_query else "generated_by_llm",
            "generated_query": query,
            "time_range": plan.time_range or "not_specified",
            "query_explanation": plan.query_explanation or ["Query dibuat oleh LLM planner berdasarkan prompt user."],
            "requires_user_review": True,
        }
