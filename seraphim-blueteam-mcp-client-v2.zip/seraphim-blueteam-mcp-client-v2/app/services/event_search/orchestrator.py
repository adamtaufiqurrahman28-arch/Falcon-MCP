from __future__ import annotations

from typing import Any, Dict

from app.core.constants import Menu
from app.models.schemas import LLMPlan
from app.services.event_search.cql_builder import CQLBuilder
from app.services.mcp_service import MCPService
from app.services.planner_service import PlannerService
from app.services.result_utils import flatten_mcp_rows


class EventSearchOrchestrator:
    """
    HIGHLIGHT: Event Search punya dua tahap:
    1. Preview query generated/manual.
    2. Execute query hanya saat user klik Run.
    """

    def __init__(self, mcp_service: MCPService, planner: PlannerService) -> None:
        self.mcp = mcp_service
        self.planner = planner
        self.builder = CQLBuilder()

    async def preview(self, prompt: str, plan: LLMPlan) -> Dict[str, Any]:
        return self.builder.preview(plan, prompt)

    async def run(self, prompt: str, plan: LLMPlan) -> Dict[str, Any]:
        preview = self.builder.preview(plan, prompt)
        query = preview.get("generated_query")
        if not query:
            return {"preview": preview, "error": "Generated query kosong. Edit query dulu sebelum run."}

        tool = plan.tool or "falcon_search_ngsiem"
        arguments = dict(plan.arguments or {})
        # HIGHLIGHT: Normalisasi argument agar query yang ditampilkan sama dengan query yang dieksekusi.
        arguments.setdefault("query", query)

        mcp_response = await self.mcp.call_tool(tool, arguments)
        rows = flatten_mcp_rows(mcp_response.get("result", []))

        summary = None
        try:
            summary = self.planner.summarize(
                Menu.EVENT_SEARCH,
                prompt,
                {"preview": preview, "row_count": len(rows), "rows_preview": rows[:15]},
            )
        except Exception:
            summary = f"Query dijalankan. Total parsed rows: {len(rows)}."

        return {
            "preview": preview,
            "executed_tool": tool,
            "executed_arguments": arguments,
            "summary": summary,
            "table": rows[:100],
            "raw": mcp_response,
        }
