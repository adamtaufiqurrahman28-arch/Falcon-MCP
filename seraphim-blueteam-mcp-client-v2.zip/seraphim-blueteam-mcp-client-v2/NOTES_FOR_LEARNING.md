# Notes for Learning

## Kenapa tidak cukup context saja?

Kalau hanya menambah prompt seperti "kamu adalah blue team analyst", AI bisa:

- salah pilih tool,
- loncat step investigasi,
- menjalankan FQL di menu Investigation,
- mengarang evidence,
- lupa menampilkan query pada Event Search.

Karena itu kita build 3 layer:

1. **LLM Planner** — memahami prompt dan membuat plan.
2. **Guardrail** — memvalidasi plan berdasarkan menu.
3. **Orchestrator** — menjalankan flow per menu secara konsisten.

## Konsep penting

```text
User prompt bukan langsung MCP call.
User prompt → LLM Plan → Guardrail → Orchestrator → MCP.
```

## File paling penting

- `planner_service.py`: tempat LLM mengubah prompt jadi structured JSON.
- `guardrail_service.py`: tempat request diblok kalau salah menu.
- `investigation/orchestrator.py`: flow blue team investigation.
- `event_search/orchestrator.py`: preview query dulu, baru run.
- `fql/orchestrator.py`: generated FQL + resource table.
