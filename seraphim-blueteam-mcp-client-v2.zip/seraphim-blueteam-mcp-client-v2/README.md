# Seraphim BlueTeam MCP Client v2

Web-based **LLM-driven MCP Client** untuk Blue Team workflow:

1. **Investigation Center** — detection/incident/IOC investigation, IOC extraction, VirusTotal enrichment, verdict, recommendation.
2. **Event Search** — NGSIEM/CQL hunting. Setiap prompt natural language wajib menampilkan generated query sebelum dieksekusi.
3. **FQL Search** — Falcon resource search untuk host, policy, sensor, grouping tag, discover, spotlight, dan resource generic.

> Ini bukan rule-based router. LLM membuat plan, lalu backend guardrail memvalidasi apakah plan boleh dijalankan pada menu tersebut.

---

## HIGHLIGHT arsitektur

```mermaid
flowchart TD
    A[Mobile Friendly Web UI] --> B[FastAPI Backend]
    B --> C[LLM Planner]
    C --> D[Structured Plan: intent/tool/args]
    D --> E[Menu Guardrail]
    E -->|Allowed| F[Workflow Orchestrator]
    E -->|Blocked| X[Blocked Response]
    F --> G[MCP Service]
    G --> H[Falcon MCP Server]
    H --> I[CrowdStrike Falcon / NGSIEM]
    I --> J[Result Parser]
    J --> K[LLM Summary / Recommendation]
    K --> L[Dashboard Output]
```

---

## HIGHLIGHT bagian penting untuk dipelajari

### 1. `app/services/planner_service.py`

Ini otak planner. LLM diberi menu context dan available MCP tools, lalu diminta menghasilkan JSON plan.

Output plan contoh:

```json
{
  "menu": "investigation",
  "intent": "find_detection_candidates",
  "tool": "falcon_search_detections",
  "arguments": {"limit": 10},
  "confidence": "medium",
  "requires_enrichment": true,
  "explanation": "User wants recent high severity detections."
}
```

### 2. `app/services/guardrail_service.py`

Ini bagian paling penting dari sisi security.

LLM boleh memilih tool, tapi backend guardrail menentukan apakah tool itu boleh dijalankan di menu tersebut.

Contoh:

- User di menu Investigation minta host search generic.
- LLM mungkin memilih `falcon_search_hosts`.
- Guardrail akan block karena Investigation hanya untuk detection/IOC investigation.

### 3. `app/services/investigation/orchestrator.py`

Ini membuat Investigation bukan sekadar prompt context.

Flow:

```text
MCP detection result
↓
IOC Extractor
↓
VirusTotal Enrichment
↓
Case Builder
↓
AI Summary
↓
Investigation Card
```

### 4. `app/services/event_search/orchestrator.py`

Event Search dibuat dua tahap:

```text
Prompt user
↓
Generated Query Preview
↓
User Run Query
↓
MCP NGSIEM Result
```

Ini sesuai requirement: setiap user request query by prompt harus menampilkan query-nya.

### 5. `app/services/fql/orchestrator.py`

FQL Search khusus Falcon resource search.

Generated FQL ditampilkan agar user bisa belajar filter yang dibuat AI.

---

## Struktur folder

```text
seraphim-blueteam-mcp-client-v2/
├── app/
│   ├── api/
│   │   └── routes.py
│   ├── core/
│   │   ├── config.py
│   │   └── constants.py
│   ├── models/
│   │   └── schemas.py
│   ├── services/
│   │   ├── llm_service.py
│   │   ├── planner_service.py
│   │   ├── guardrail_service.py
│   │   ├── mcp_service.py
│   │   ├── audit_service.py
│   │   ├── investigation/
│   │   │   ├── orchestrator.py
│   │   │   ├── ioc_extractor.py
│   │   │   ├── virustotal_service.py
│   │   │   └── case_builder.py
│   │   ├── event_search/
│   │   │   ├── orchestrator.py
│   │   │   └── cql_builder.py
│   │   └── fql/
│   │       ├── orchestrator.py
│   │       └── fql_builder.py
│   ├── static/img/
│   │   └── seraphim-blueteam-logo.png
│   ├── web/
│   │   └── templates.py
│   └── main.py
├── requirements.txt
├── .env.example
├── .gitignore
└── run.py
```

---

## Setup

```bash
cd seraphim-blueteam-mcp-client-v2
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Isi `.env` minimal:

```env
MCP_SERVER_URL=http://127.0.0.1:8000/mcp
LLM_ENABLED=true
LLM_API_KEY=ISI_API_KEY_KAMU
LLM_BASE_URL=https://api.openai.com/v1
LLM_MODEL=gpt-4o-mini
VT_ENABLED=false
VT_API_KEY=
```

Run:

```bash
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8080
```

Buka:

```text
http://SERVER-IP:8080
```

---

## Falcon MCP Docker contoh

```bash
docker run -d \
  --name falcon-mcp \
  --restart unless-stopped \
  -p 127.0.0.1:8000:8000 \
  --env-file /opt/falcon-mcp/.env \
  quay.io/crowdstrike/falcon-mcp:latest \
  --transport streamable-http \
  --host 0.0.0.0 \
  --port 8000 \
  --modules hosts,detections,incidents,ngsiem,discover,spotlight,sensorusage,rtr,ioc,intel,firewall,idp,scheduledreports
```

---

## API endpoints

### Health

```http
GET /api/health
```

### List MCP tools

```http
GET /api/tools
```

### Unified prompt endpoint

```http
POST /api/prompt
```

Payload Investigation:

```json
{
  "menu": "investigation",
  "prompt": "Investigasi detection high severity terbaru",
  "execute": false
}
```

Payload Event Search preview:

```json
{
  "menu": "event_search",
  "prompt": "Cari failed RDP login 7 hari terakhir",
  "execute": false
}
```

Payload Event Search run:

```json
{
  "menu": "event_search",
  "prompt": "Cari failed RDP login 7 hari terakhir",
  "execute": true
}
```

Payload FQL:

```json
{
  "menu": "fql",
  "prompt": "Cari host Windows Server dengan sensor lama",
  "execute": false
}
```

---

## Security design

### Yang diblok di Investigation

- FQL generic host/policy search
- NGSIEM manual query
- policy update
- grouping tag update
- RTR
- containment
- delete/create IOA

### Yang diblok di Event Search

- FQL host/policy search
- tag/policy update
- RTR
- containment

### Yang butuh preview/confirmation di FQL

- add grouping tag
- update policy
- assign policy
- any write/destructive action

---

## Catatan penting

1. Tool name Falcon MCP bisa berbeda tergantung versi/module. LLM Planner membaca `/api/tools`, tapi prompt system dan guardrail mungkin perlu penyesuaian nama tool.
2. `VT_ENABLED=false` aman untuk awal. Setelah API key siap, set `VT_ENABLED=true`.
3. Jangan expose Falcon MCP port `8000` ke public. Bind ke `127.0.0.1` saja.
4. Jangan commit `.env`.
5. `/api/tool` ada untuk debug/admin, tapi tetap lewat guardrail.
